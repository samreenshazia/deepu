import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-zoom',
  templateUrl: './zoom.component.html',
  styleUrls: ['./zoom.component.css']
})
export class ZoomComponent implements OnInit {
  product:ProductService
  constructor( product:ProductService) {this.product=product }

  ngOnInit() {
    
  }
   zooming(){
    this.product.zoom();
}

}
