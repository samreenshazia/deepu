import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ZoomComponent } from './zoom/zoom.component';
import { SlideComponent } from './slide/slide.component';

const routes: Routes = [
  {
    path:"zoom",component:ZoomComponent
},
{
  path:"slide",component:SlideComponent
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
