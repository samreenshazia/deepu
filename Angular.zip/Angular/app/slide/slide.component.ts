import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-slide',
  templateUrl: './slide.component.html',
  styleUrls: ['./slide.component.css']
})
export class SlideComponent implements OnInit {
  product:ProductService
  constructor( product:ProductService) {this.product=product }

  ngOnInit() {
  
  }
 sliding(){
   this.product.slide();
 }
}
