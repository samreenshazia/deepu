import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ProductService {
  httpclient:HttpClient;

  constructor(httpclient:HttpClient) {this.httpclient=httpclient; }

  zoom(){
  
   return this.httpclient.get('http://localhost:1113/zoom');

  }
  slide(){
  
    return this.httpclient.get('http://localhost:1113/slide');

  }
}
